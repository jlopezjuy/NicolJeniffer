package ar.com.juanlopez.clohes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClothesRestServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClothesRestServiceApplication.class, args);
	}
}
