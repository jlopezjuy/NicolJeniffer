$(document).ready(function() {
     
      $("#owl-demo").owlCarousel({
     
         navigation : false, // Show next and prev buttons
    	slideSpeed : 3000,
		autoPlay: false,
    	paginationSpeed : 400,
    	singleItem:true
     
      });
	  
	  $("#owl-demo-2").owlCarousel({
     
         navigation : false, // Show next and prev buttons
    	slideSpeed : 3000,
		autoPlay: false,
    	paginationSpeed : 400,
    	singleItem:true
     
      });
	  
	  
	  $("#owl-demo-3").owlCarousel({
     	
		// Most important owl features
        items : 3,
        itemsCustom : false,
        itemsDesktop : [1199,3],
        itemsDesktopSmall : [980,3],
        itemsTablet: [768,2],
        itemsTabletSmall: false,
        itemsMobile : [480,1],
        singleItem : false,
        itemsScaleUp : false,
		navigation : false, // Show next and prev buttons
    	slideSpeed : 3000,
		autoPlay: true,
    	paginationSpeed : 400,
     
      });
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
     
    });


